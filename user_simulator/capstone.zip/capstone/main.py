###########################################################################################################
#This function captures Client actions for Passenger Simulation
###########################################################################################################
from user_simulator import User
import time
import json
from termcolor import colored


class UserSimulatorClient:

    def __init__(self):
        self._latest_error = ''
        self._origin=''
        self._destination=''
        self._otp = ''
        self._apiKey = ''
        self._User = User()
        self._user_id = ''
        self._book_again ='Yes'
        self. _start_ride= 1
        self._booked_time=''
        self.ride_details=[]


    def Sign_Up(self):
        print(colored('''
                                        ===================
                                              Sign up
                                        ===================
                    ''','magenta'))

        first_name = input(colored("Please enter your First Name: ", 'cyan'))
        last_name = input(colored("Please enter your Last Name: ", 'cyan'))

        response = User().passenger_signup(first_name, last_name)
        if response != 'None':
            print(colored(f'''Sign Up successful. Please find your login details below
Username: {response['UserName']}, Password:{response['Password']}
Please login to Book a Taxi''',"green"))
            return response
        else :
            print(colored('Sign Up Unsuccessful. Please try again','red'))



    def Sign_In(self):
        try:
            print(colored('''
                                        ===================
                                              Sign in 
                                        ===================  
                            ''', 'magenta'))
            print(colored("Enter Login Details:","green"))
            count=3

            while (self._apiKey  == "" and count>0):

                user_id = input(colored("UserName: ", 'cyan'))
                password = input(colored("Password: ", 'cyan'))
                res = User().passenger_login(user_id, password)
                #print(res)

                if res == None:
                    print(colored("Invalid Login. Try again:", 'red'))
                    count-=1
                else:
                    print(colored("You have Logged in Successfully:", "green"))
                    res_dict = json.loads(res)
                    #print(res_dict)
                    self._apiKey = res_dict['APIKey']
                    self._user_id = user_id
                    self.Book_Taxi()
        except Exception as err:
            print(colored("Invalid Input. Try again later:", 'red'))

    def Book_Taxi(self):
        print(colored('''
                                        ============================
                                          Initiating Taxi Booking
                                        ============================   
                      ''', 'magenta'))
        while(self._book_again.lower() =='yes'):
            print(colored('Note: Address and lat,long formats accepted in Origin and Destination','magenta'))
            self._origin = input(colored("Origin: ", 'cyan'))
            self._destination = input(colored("Destination: ", 'cyan'))
            taxi_type_options = ["UTILITY", "DELUXE", "LUXURY", "ALL"]
            # Print out your options
            for i in range(len(taxi_type_options)):
                print(str(i + 1) + ":", taxi_type_options[i])
            result = "Noresult"
            # Take user input and get the corresponding item from the list
            book_taxi_retry = 3# if no rides available user can retry two more times for different taxi type
            while (result == "Noresult" and book_taxi_retry>0):
                taxi_type = int(input(colored("Enter Taxi Type number: ", 'cyan')))
                if taxi_type in range(1, 5):
                    taxi_type = taxi_type_options[taxi_type - 1]
                    res = User().book_taxi(self._user_id, self._origin, self._destination, taxi_type)

                    if res == None:
                        print('Sorry. No rides available at this moment.Please try again with different taxi type')
                        book_taxi_retry -=1

                    else:
                        self._book_again ='no'
                        book_taxi_retry = 0
                        self.ride_details = res
                        print(colored('Please find the cost for closest available taxi', 'green'))
                        print(
                            ' '.join(["Taxi type: " + self.ride_details['vehicle_type'], "Cost: " + self.ride_details['cost']]))
                        self.Confirm_Taxi()
                        result = "Pass"
                else:
                    print(colored('Wrong Input. Please try again','red'))
            if result != "Pass":
                self._book_again = input(
                    colored("Sorry. No rides available at this moment.Do you want to try searching again?(yes/no):", 'cyan'))



    def Confirm_Taxi(self):
        try:

            confirm_booking = input(colored("Would you like to confirm this booking?(yes/no) :", 'cyan'))
            if confirm_booking.lower() == 'yes':

                res, self._booked_time = User().book_taxi_confirm(self._user_id, self.ride_details['vehicle_num'], self._origin, self._destination, self.ride_details['vehicle_type'], self._apiKey)
                #print(res)
                if (res != None):
                    print(colored('Your ride is confirmed. Please find the ride details below:', 'green'))
                    res_dict = json.loads(res)

                    Driver_Name = ' '.join([self.ride_details['firstname'], self.ride_details['lastname']])
                    print(colored(' '.join(["Taxi Number: " + self.ride_details['vehicle_num'], "Driver Name: " + Driver_Name,
                                            "Taxi type: " + self.ride_details['vehicle_type'], "Cost: " + self.ride_details['cost']]),
                                  'green'))
                    self._otp = res_dict["OTP"]
                    print(f'Please note:Your OTP to start the ride is  {colored(self._otp,"green")}')
                    res = User().get_ride_details(self._apiKey, self._booked_time)

                    wait_ride = 1
                    while (wait_ride):
                        print(colored('''
                                ============================================
                                         Waiting for the ride
                                ============================================   
                                                      ''', 'magenta'))

                        address, distance = User().get_taxi_curr_location(self._origin, self._otp,
                                                                                       self.ride_details['vehicle_num'])
                        print(
                            f'your driver is in {colored(address, "green")} and is {colored(format(distance, ".2f"), "green")} Km(s) away from your location')
                        if (distance < 0.5):#if driver is less than half a Km away from location then start ride is enabled for the user
                            #time.sleep(10)
                            self.Start_Ride()
                            wait_ride = 0
                            break
                        else:
                            time.sleep(60)#wait for a min before checking for current location of the taxi again


                    end_ride = 1
                    while (end_ride):
                        print(colored('''
                                ============================================
                                        Taxi Moving
                                ============================================   
                                         ''', 'magenta'))

                        address,distance = User().get_taxi_curr_location(self._destination, self._otp, self.ride_details['vehicle_num'])
                        print(
                            f'you are in {colored(address, "magenta")} and are {colored(format(distance, ".2f"), "magenta")} Km(s) away from your Destination')

                        if (distance < 0.5):#if passenger is less than half a Km away from destination then end ride is initiated for the user
                            print(colored("You have reached your destination. Hope you had a wonderful trip!", 'green'))
                            self.End_Ride()
                            print(colored('''
                                ============================================
                                           Ride has Ended
                                ============================================   
                                            ''', 'magenta'))

                            end_ride = 0
                            break
                        else:
                            time.sleep(60)#wait for a min before checking for current location of the taxi again
                else:
                    print(colored('Your ride is not confirmed. Please try booking the ride again:', 'red'))

            else:
                self._book_again = input(colored("Do you want to try searching for taxi again?(yes/no):", "cyan"))


        except Exception as err:
            self.End_Ride()
    def Start_Ride(self):

            try:
                count = 3 # to retry OTP entry 3 times in case of wrong entry
                while (count > 0):
                    OTP = input(colored("Your ride has arrived.Please provide your OTP to start the ride: ", 'cyan'))


                    if (OTP==self._otp):
                        res = User().start_ride(OTP, self.ride_details['vehicle_num'], self._origin, self._destination, self._apiKey)
                        #print(res)
                        if (res != None):
                            print(colored('''
                                ============================================
                                                Ride Started
                                ============================================   
                                          ''', 'magenta'))
                            print(colored(f'Your ride has started at{res}. You can track your ride now. Happy Journey!!','green'))

                            res = User().get_ride_details(self._apiKey, self._booked_time)
                            count=0

                        else:
                            print(colored("Sorry. we could not start your ride. Please try again later","red"))
                            count =0
                            break
                    else:
                        count -= 1
                        print(colored(f"Invalid OTP. {count} more attempts left. Try again:", 'red'))


            except Exception as err:
                self.End_Ride()


    def End_Ride(self):
        res = User().end_ride(self._otp, self.ride_details['vehicle_num'], self._apiKey)

        feedback = input(colored("would you like to give your feedback(yes/no)? ", 'cyan'))
        if feedback == "yes":
            rating_options = ["Very happy", "Happy", "Neutral", "Unhappy", "Very Unhappy"]
            j = 5
            # Print out your options
            for i in range(len(rating_options)):
                print(str(j) + ":", rating_options[i])
                j -= 1
            rating = input(colored("On a scale of 1 to 5 ,how would you like to rate your trip ? ","cyan"))
            comments = input(colored("Please provide your comments here: ","cyan"))

            res = User().feedback(self._otp, self._apiKey, comments, rating)
            if (res != None):
                print(colored("Thank you for your feedback","green"))




def user_simulator():
    try:
        print(colored('''
                                        =======================
                                           Sign Up/ Sign In
                                        =======================   
               ''', 'magenta'))
        Sign_in_Options = ["Sign Up", "Sign In"]

        # Print out your options
        for i in range(len(Sign_in_Options)):
            print(str(i + 1) + ":", Sign_in_Options[i])
        result = "Noresult"
        # Take user input and get the corresponding item from the list
        while (result == "Noresult"):
            inp = int(input(colored("Enter Sign Up/Sign In option number ", 'cyan')))

            if int(inp) in range(1, 3):
                inp = Sign_in_Options[inp - 1]
                result = "Pass"
                if (inp == "Sign Up"):
                    UserSimulatorClient().Sign_Up()
                    book_taxi = input(colored("Would you like to book a taxi (yes/no)?", 'cyan'))
                    if book_taxi.lower() =="yes":
                        UserSimulatorClient().Sign_In()
                else:
                    UserSimulatorClient().Sign_In()
            else:
                print(colored("Invalid input. Try again!", 'red'))

    except Exception as err:
        print(colored("Invalid input. Try again later!", 'red'))
if __name__ == "__main__":

    user_simulator()







